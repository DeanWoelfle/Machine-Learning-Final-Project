import os
import pandas as pd
import numpy as np
import pymc as pm
import arviz as az
import matplotlib
matplotlib.use('svg')
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, confusion_matrix
from scipy.stats import norm as scipy_norm
from matplotlib.colors import ListedColormap, to_rgba
import pickle
from scipy.special import logsumexp

DATA_FILE = 'preprocessed_peng_data.csv'
FIGURES_DIR_BASE = 'figures_naive_bayes'
CHECKPOINTS_DIR = 'model_checkpoints_naive_bayes'
MODEL_TRACE_FILE = os.path.join(CHECKPOINTS_DIR, 'naive_bayes_model_trace.nc')

os.makedirs(CHECKPOINTS_DIR, exist_ok=True)

N_LABELS_EXPECTED = 13
N_SAMPLES = 4000
N_TUNE = 2000
SPECIES_QUANTITY_VALUES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30]

def product_of_probabilities_normalized(prob_arrays_list):
    if not prob_arrays_list:
        return np.ones(N_LABELS_EXPECTED) / N_LABELS_EXPECTED
    
    prob_arrays = np.array(prob_arrays_list)
    if prob_arrays.ndim == 1:
        if len(prob_arrays) == N_LABELS_EXPECTED:
             return prob_arrays / np.sum(prob_arrays)
        else:
            return np.ones(N_LABELS_EXPECTED) / N_LABELS_EXPECTED

    if prob_arrays.shape[1] != N_LABELS_EXPECTED:
        return np.ones(N_LABELS_EXPECTED) / N_LABELS_EXPECTED

    combined_probs = np.prod(prob_arrays, axis=0)
    norm_sum = np.sum(combined_probs)
    if norm_sum < 1e-9:
        return np.ones_like(combined_probs) / len(combined_probs)
    return combined_probs / norm_sum

def average_of_probabilities_normalized(prob_arrays_list):
    if not prob_arrays_list:
        return np.ones(N_LABELS_EXPECTED) / N_LABELS_EXPECTED

    prob_arrays = np.array(prob_arrays_list)
    if prob_arrays.ndim == 1:
        if len(prob_arrays) == N_LABELS_EXPECTED:
             return prob_arrays / np.sum(prob_arrays)
        else:
            return np.ones(N_LABELS_EXPECTED) / N_LABELS_EXPECTED
            
    if prob_arrays.shape[1] != N_LABELS_EXPECTED:
        return np.ones(N_LABELS_EXPECTED) / N_LABELS_EXPECTED
        
    combined_probs = np.mean(prob_arrays, axis=0)
    norm_sum = np.sum(combined_probs)
    if norm_sum < 1e-9:
        return np.ones_like(combined_probs) / len(combined_probs)
    return combined_probs / norm_sum


def plot_gaussian_2d_density_map(mean_lon, std_lon, mean_lat, std_lat,
                                 grid_lon_vals, grid_lat_vals,
                                 ax=None, base_color=None, contour_line_color='black',
                                 label_name_for_legend=None, fill_alpha=0.3, scatter_data=None):
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 8))

    LonMesh, LatMesh = np.meshgrid(grid_lon_vals, grid_lat_vals)

    pdf_lon = scipy_norm.pdf(LonMesh, loc=mean_lon, scale=std_lon + 1e-6)
    pdf_lat = scipy_norm.pdf(LatMesh, loc=mean_lat, scale=std_lat + 1e-6)
    Z = pdf_lon * pdf_lat

    if base_color:
        rgba_color = to_rgba(base_color)
        custom_cmap = ListedColormap([(*rgba_color[:3], alpha_val) for alpha_val in np.linspace(0.05, rgba_color[3]*fill_alpha, 256)])
        ax.contourf(LonMesh, LatMesh, Z, levels=20, cmap=custom_cmap)

    if contour_line_color and contour_line_color != 'none':
        ax.contour(LonMesh, LatMesh, Z, levels=5, colors=contour_line_color, alpha=0.6, linewidths=0.8)

    if scatter_data is not None and len(scatter_data) > 0:
        ax.scatter(scatter_data[:, 1], scatter_data[:, 0], s=5, alpha=0.1, color=base_color if base_color else 'blue', label=f'Data points' if label_name_for_legend else None)

    ax.set_xlabel('Longitude')
    ax.set_ylabel('Latitude')
    if label_name_for_legend:
        ax.set_title(f'Learned Gaussian Density for: {label_name_for_legend}')
    return ax

print("\nLoading and preprocessing data...")
TRAIN_DATA_CACHE = os.path.join(CHECKPOINTS_DIR, 'train_data_nb.pkl')
TEST_DATA_CACHE = os.path.join(CHECKPOINTS_DIR, 'test_data_nb.pkl')
LABEL_ENCODER_CACHE = os.path.join(CHECKPOINTS_DIR, 'label_encoder_nb.pkl')

SAMPLES_PER_LABEL = 80000

if os.path.exists(TRAIN_DATA_CACHE) and os.path.exists(TEST_DATA_CACHE) and os.path.exists(LABEL_ENCODER_CACHE):
    train_df = pd.read_pickle(TRAIN_DATA_CACHE)
    test_df = pd.read_pickle(TEST_DATA_CACHE)
    with open(LABEL_ENCODER_CACHE, 'rb') as f:
        label_encoder = pickle.load(f)
    unique_labels = label_encoder.classes_
    N_LABELS_EXPECTED = len(unique_labels)
    
    X_train = train_df[['decimalLatitude', 'decimalLongitude']].values
    y_train = train_df['label_encoded'].values
    X_test = test_df[['decimalLatitude', 'decimalLongitude']].values
    y_test = test_df['label_encoded'].values

else:
    try:
        full_df = pd.read_csv(DATA_FILE)
        if 'verbatimScientificName' not in full_df.columns or \
           'decimalLatitude' not in full_df.columns or \
           'decimalLongitude' not in full_df.columns:
            exit()
        full_df.dropna(subset=['verbatimScientificName', 'decimalLatitude', 'decimalLongitude'], inplace=True)
    except FileNotFoundError:
        exit()
    except Exception as e:
        exit()

    grouped = full_df.groupby('verbatimScientificName')
    sampled_dfs = []
    for name, group in grouped:
        if len(group) >= SAMPLES_PER_LABEL:
            sampled_dfs.append(group.sample(n=SAMPLES_PER_LABEL, random_state=360))
        else:
            sampled_dfs.append(group)
    if not sampled_dfs: 
        exit("No data after sampling.")
    df = pd.concat(sampled_dfs).reset_index(drop=True)

    label_encoder = LabelEncoder()
    df['label_encoded'] = label_encoder.fit_transform(df['verbatimScientificName'])
    unique_labels = label_encoder.classes_
    N_LABELS_EXPECTED = len(unique_labels)

    with open(LABEL_ENCODER_CACHE, 'wb') as f: pickle.dump(label_encoder, f)

    X = df[['decimalLatitude', 'decimalLongitude']].values
    y = df['label_encoded'].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=360, stratify=y)

    train_df = pd.DataFrame(X_train, columns=['decimalLatitude', 'decimalLongitude'])
    train_df['label_encoded'] = y_train
    test_df = pd.DataFrame(X_test, columns=['decimalLatitude', 'decimalLongitude'])
    test_df['label_encoded'] = y_test

    train_df.to_pickle(TRAIN_DATA_CACHE)
    test_df.to_pickle(TEST_DATA_CACHE)

overall_lat_mean, overall_lat_std = X_train[:, 0].mean(), X_train[:, 0].std()
overall_lon_mean, overall_lon_std = X_train[:, 1].mean(), X_train[:, 1].std()

print("\nTraining or loading model...")

inference_data = None
if os.path.exists(MODEL_TRACE_FILE):
    print(f"Model found, loading model...")
    try:
        inference_data = az.from_netcdf(MODEL_TRACE_FILE)
    except Exception as e:
        inference_data = None

if inference_data is None:
    if N_LABELS_EXPECTED == 0:
        exit()
    print("Buidling and training model...")
    with pm.Model() as naive_bayes_model:
        p_label = pm.Dirichlet('p_label', a=np.ones(N_LABELS_EXPECTED))
        mu_lats = pm.Normal('mu_lats', mu=overall_lat_mean, sigma=overall_lat_std * 2, shape=N_LABELS_EXPECTED)
        sigma_lats = pm.HalfNormal('sigma_lats', sigma=overall_lat_std * 2, shape=N_LABELS_EXPECTED)
        mu_lons = pm.Normal('mu_lons', mu=overall_lon_mean, sigma=overall_lon_std * 2, shape=N_LABELS_EXPECTED)
        sigma_lons = pm.HalfNormal('sigma_lons', sigma=overall_lon_std * 2, shape=N_LABELS_EXPECTED)
        lat_likelihood = pm.Normal('lat_like',
                                   mu=mu_lats[y_train],
                                   sigma=sigma_lats[y_train],
                                   observed=X_train[:, 0])
        lon_likelihood = pm.Normal('lon_like',
                                   mu=mu_lons[y_train],
                                   sigma=sigma_lons[y_train],
                                   observed=X_train[:, 1])
    try:
        with naive_bayes_model:
            trace = pm.sample(N_SAMPLES, tune=N_TUNE, chains=2, cores=1, random_seed=360, target_accept=0.9)
        inference_data = trace
        inference_data.to_netcdf(MODEL_TRACE_FILE)
    except Exception as e:
        inference_data = None


print("\nEvaluating model and creating figures...")
os.makedirs(FIGURES_DIR_BASE, exist_ok=True)

if inference_data is None:
    pass
else:
    posterior_means = {
        'p_label': inference_data.posterior['p_label'].mean(dim=('chain', 'draw')).values,
        'mu_lats': inference_data.posterior['mu_lats'].mean(dim=('chain', 'draw')).values,
        'sigma_lats': inference_data.posterior['sigma_lats'].mean(dim=('chain', 'draw')).values,
        'mu_lons': inference_data.posterior['mu_lons'].mean(dim=('chain', 'draw')).values,
        'sigma_lons': inference_data.posterior['sigma_lons'].mean(dim=('chain', 'draw')).values,
    }

    padding_factor = 1.5
    lon_min_plot = X_train[:, 1].min() - overall_lon_std * padding_factor
    lon_max_plot = X_train[:, 1].max() + overall_lon_std * padding_factor
    lat_min_plot = X_train[:, 0].min() - overall_lat_std * padding_factor
    lat_max_plot = X_train[:, 0].max() + overall_lat_std * padding_factor
    grid_lon_vals = np.linspace(lon_min_plot, lon_max_plot, 100)
    grid_lat_vals = np.linspace(lat_min_plot, lat_max_plot, 100)
    
    label_plot_colors = plt.cm.get_cmap('tab20', N_LABELS_EXPECTED)

    for i in range(N_LABELS_EXPECTED):
        label_name = label_encoder.classes_[i]
        fig_label, ax_label = plt.subplots(figsize=(10, 8))
        label_train_data_points = X_train[y_train == i]

        plot_gaussian_2d_density_map(
            mean_lon=posterior_means['mu_lons'][i], std_lon=posterior_means['sigma_lons'][i],
            mean_lat=posterior_means['mu_lats'][i], std_lat=posterior_means['sigma_lats'][i],
            grid_lon_vals=grid_lon_vals, grid_lat_vals=grid_lat_vals,
            ax=ax_label, base_color=label_plot_colors(i), contour_line_color='black',
            label_name_for_legend=label_name, fill_alpha=0.5,
            scatter_data=label_train_data_points
        )
        ax_label.legend([plt.Line2D([0], [0], color=label_plot_colors(i), lw=4)], [f'{label_name} Density and Data'])
        fig_label.savefig(os.path.join(FIGURES_DIR_BASE, f'density_map_trained_NB_{label_name.replace(" ", "_")}.svg'))
        fig_label.savefig(os.path.join(FIGURES_DIR_BASE, f'density_map_trained_NB_{label_name.replace(" ", "_")}.png'))
        plt.close(fig_label)

    fig_all_labels, ax_all_labels = plt.subplots(figsize=(20, 10))
    legend_handles = []

    for i in range(N_LABELS_EXPECTED):
        label_name = label_encoder.classes_[i]
        color = label_plot_colors(i)

        plot_gaussian_2d_density_map(
            mean_lon=posterior_means['mu_lons'][i], std_lon=posterior_means['sigma_lons'][i],
            mean_lat=posterior_means['mu_lats'][i], std_lat=posterior_means['sigma_lats'][i],
            grid_lon_vals=grid_lon_vals, grid_lat_vals=grid_lat_vals,
            ax=ax_all_labels, base_color=color, contour_line_color=None,
            fill_alpha=0.50
        )
        mean_marker = ax_all_labels.plot(posterior_means['mu_lons'][i], posterior_means['mu_lats'][i],
                                            marker='o', color=color,
                                            markeredgecolor='black', markersize=8, linestyle='None')[0]
        legend_handles.append(mean_marker)

    ax_all_labels.set_xlabel('Longitude')
    ax_all_labels.set_ylabel('Latitude')
    ax_all_labels.set_title('Overlay of Learned Gaussian Densities with Mean Markers')
    ax_all_labels.legend(legend_handles, label_encoder.classes_, title="Labels",
                         bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    fig_all_labels.savefig(os.path.join(FIGURES_DIR_BASE, 'combined_density_maps_NB.svg'))
    fig_all_labels.savefig(os.path.join(FIGURES_DIR_BASE, 'combined_density_maps_NB.png'))
    plt.close(fig_all_labels)


print("\nTesting model...")
def predict_label_probabilities_naive_bayes(new_point_lat_lon, trace_idata, n_labels_for_pred):
    if trace_idata is None:
        return np.ones(n_labels_for_pred) / n_labels_for_pred

    post = trace_idata.posterior
    p_label_samples = post['p_label'].values.reshape(-1, n_labels_for_pred)
    mu_lats_samples = post['mu_lats'].values.reshape(-1, n_labels_for_pred)
    sigma_lats_samples = post['sigma_lats'].values.reshape(-1, n_labels_for_pred)
    mu_lons_samples = post['mu_lons'].values.reshape(-1, n_labels_for_pred)
    sigma_lons_samples = post['sigma_lons'].values.reshape(-1, n_labels_for_pred)
    n_posterior_samples = p_label_samples.shape[0]

    lat, lon = new_point_lat_lon[0], new_point_lat_lon[1]
    
    log_posterior_probs_for_samples = np.zeros((n_posterior_samples, n_labels_for_pred))

    for i in range(n_labels_for_pred):
        log_p_lat_given_label_i = scipy_norm.logpdf(lat, loc=mu_lats_samples[:, i], scale=sigma_lats_samples[:, i] + 1e-6)
        log_p_lon_given_label_i = scipy_norm.logpdf(lon, loc=mu_lons_samples[:, i], scale=sigma_lons_samples[:, i] + 1e-6)
        log_p_label_i = np.log(p_label_samples[:, i] + 1e-9)
        log_posterior_probs_for_samples[:, i] = log_p_lat_given_label_i + log_p_lon_given_label_i + log_p_label_i
    
    final_log_probs = np.array([logsumexp(log_posterior_probs_for_samples[:, i]) - np.log(n_posterior_samples) for i in range(n_labels_for_pred)])
    
    max_log_prob = np.max(final_log_probs[np.isfinite(final_log_probs)])
    if not np.isfinite(max_log_prob):
        return np.ones(n_labels_for_pred) / n_labels_for_pred
    
    probs = np.exp(final_log_probs - max_log_prob)
    probs_sum = np.sum(probs)
    return probs / probs_sum if probs_sum > 1e-9 else np.ones(n_labels_for_pred) / n_labels_for_pred

X_test_coords = test_df[['decimalLatitude', 'decimalLongitude']].values
y_test_labels_true = test_df['label_encoded'].values

test_data_by_label = {}
for label_idx in range(N_LABELS_EXPECTED):
    test_data_by_label[label_idx] = X_test_coords[y_test_labels_true == label_idx]

testing_methods_config = [
    {"name": "Normalized Product", "combiner": product_of_probabilities_normalized, "suffix": "_ProdProb"},
    {"name": "Average", "combiner": average_of_probabilities_normalized, "suffix": "_AvgProb"}
]

all_methods_testing_results = {}


if inference_data is None:
    pass
else:
    for method_config in testing_methods_config:
        method_name = method_config["name"]
        prob_combiner = method_config["combiner"]
        file_suffix = method_config["suffix"]
        
        current_method_figures_dir = os.path.join(FIGURES_DIR_BASE, method_name)
        os.makedirs(current_method_figures_dir, exist_ok=True)

        print(f"\nTesting method: {method_name} ")
        
        all_sq_results_for_current_method = {}

        for sq_value in SPECIES_QUANTITY_VALUES:
            print(f"  Testing with example quantity = {sq_value} ({method_name}) ")
            current_sq_predictions = []
            current_sq_true_labels = []
            current_sq_combined_probs_list = []

            for test_idx in range(len(X_test_coords)):
                if test_idx % (max(1, len(X_test_coords) // 20)) == 0:
                    print(f"    {method_name}, example quantity = {sq_value}, Testing point {test_idx+1}/{len(X_test_coords)}")

                main_test_point_lat_lon = X_test_coords[test_idx]
                true_label_of_main_point = y_test_labels_true[test_idx]
                
                points_to_evaluate_lat_lon = [main_test_point_lat_lon]

                if sq_value > 1:
                    additional_points_needed = sq_value - 1
                    potential_indices_full_test_set = np.where(y_test_labels_true == true_label_of_main_point)[0]
                    other_indices_of_same_label_in_test = potential_indices_full_test_set[potential_indices_full_test_set != test_idx]

                    if len(other_indices_of_same_label_in_test) > 0:
                        num_to_sample = min(additional_points_needed, len(other_indices_of_same_label_in_test))
                        chosen_indices = np.random.choice(other_indices_of_same_label_in_test, size=num_to_sample, replace=False)
                        for chosen_idx in chosen_indices:
                            points_to_evaluate_lat_lon.append(X_test_coords[chosen_idx])
                    
                    current_eval_source = list(points_to_evaluate_lat_lon)
                    while len(points_to_evaluate_lat_lon) < sq_value and len(current_eval_source) > 0:
                        points_to_evaluate_lat_lon.append(current_eval_source[np.random.choice(len(current_eval_source))])
                
                individual_probs_for_combination = []
                for point_lat_lon in points_to_evaluate_lat_lon:
                    probs = predict_label_probabilities_naive_bayes(point_lat_lon, inference_data, N_LABELS_EXPECTED)
                    individual_probs_for_combination.append(probs)
                
                if not individual_probs_for_combination:
                    final_probs = np.ones(N_LABELS_EXPECTED) / N_LABELS_EXPECTED
                else:
                    final_probs = prob_combiner(individual_probs_for_combination)

                predicted_label = np.argmax(final_probs)
                current_sq_predictions.append(predicted_label)
                current_sq_true_labels.append(true_label_of_main_point)
                current_sq_combined_probs_list.append(final_probs)

            all_sq_results_for_current_method[sq_value] = {
                'predictions': np.array(current_sq_predictions),
                'true_labels': np.array(current_sq_true_labels),
                'probabilities': np.array(current_sq_combined_probs_list)
            }

            acc = accuracy_score(all_sq_results_for_current_method[sq_value]['true_labels'],
                                 all_sq_results_for_current_method[sq_value]['predictions'])
            print(f"    {method_name}, Example Quantity = {sq_value}, Overall Accuracy = {acc:.4f}")

            cm = confusion_matrix(all_sq_results_for_current_method[sq_value]['true_labels'],
                                  all_sq_results_for_current_method[sq_value]['predictions'],
                                  labels=np.arange(N_LABELS_EXPECTED))
            plt.figure(figsize=(max(8, N_LABELS_EXPECTED * 0.6), max(6, N_LABELS_EXPECTED * 0.5)))
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                        xticklabels=label_encoder.classes_, yticklabels=label_encoder.classes_)
            plt.xlabel('Predicted Label')
            plt.ylabel('True Label')
            plt.title(f'CM for Examples={sq_value} ({method_name}) (Acc: {acc:.3f})')
            plt.xticks(rotation=45, ha='right'); plt.yticks(rotation=0)
            plt.tight_layout()
            plt.savefig(os.path.join(current_method_figures_dir, f'confusion_matrix_sq_{sq_value}{file_suffix}_NB.svg'))
            plt.savefig(os.path.join(current_method_figures_dir, f'confusion_matrix_sq_{sq_value}{file_suffix}_NB.png'))
            plt.close()

            accuracies_per_label_sq = []
            labels_with_test_samples_sq = []
            for lbl_idx in range(N_LABELS_EXPECTED):
                true_for_lbl = all_sq_results_for_current_method[sq_value]['true_labels'][all_sq_results_for_current_method[sq_value]['true_labels'] == lbl_idx]
                pred_for_lbl = all_sq_results_for_current_method[sq_value]['predictions'][all_sq_results_for_current_method[sq_value]['true_labels'] == lbl_idx]
                if len(true_for_lbl) > 0:
                    accuracies_per_label_sq.append(accuracy_score(true_for_lbl, pred_for_lbl))
                    labels_with_test_samples_sq.append(label_encoder.classes_[lbl_idx])
            
            if labels_with_test_samples_sq:
                plt.figure(figsize=(max(10, N_LABELS_EXPECTED * 0.7), 7))
                sns.barplot(x=labels_with_test_samples_sq, y=accuracies_per_label_sq)
                plt.xlabel('Label'); plt.ylabel('Accuracy')
                plt.title(f'Accuracy per Label, Examples={sq_value} ({method_name})')
                plt.xticks(rotation=45, ha='right'); plt.tight_layout()
                plt.savefig(os.path.join(current_method_figures_dir, f'accuracy_per_label_examples_{sq_value}{file_suffix}_NB.svg'))
                plt.savefig(os.path.join(current_method_figures_dir, f'accuracy_per_label_examples_{sq_value}{file_suffix}_NB.png'))
                plt.close()
        
        all_methods_testing_results[method_name] = all_sq_results_for_current_method

print("\nDisplaying testing analysis...")

sq_values_plotted = sorted(SPECIES_QUANTITY_VALUES)

for method_name, results_for_method in all_methods_testing_results.items():
    if not results_for_method: continue
    
    current_method_figures_dir = os.path.join(FIGURES_DIR_BASE, method_name)
    file_suffix = testing_methods_config[[m["name"] for m in testing_methods_config].index(method_name)]["suffix"]

    overall_accuracies_plot = []
    valid_sq_for_plot = []
    for sq_val in sq_values_plotted:
        if sq_val in results_for_method:
            acc = accuracy_score(results_for_method[sq_val]['true_labels'], results_for_method[sq_val]['predictions'])
            overall_accuracies_plot.append(acc)
            valid_sq_for_plot.append(sq_val)
        
    if overall_accuracies_plot:
        plt.figure(figsize=(10, 6))
        plt.plot(valid_sq_for_plot, overall_accuracies_plot, marker='o', linestyle='-')
        plt.xlabel('Examples'); plt.ylabel('Overall Accuracy')
        plt.title(f'Overall Accuracy vs. Examples ({method_name}) (NB)')
        plt.xticks(valid_sq_for_plot); plt.grid(True); plt.tight_layout()
        plt.savefig(os.path.join(current_method_figures_dir, f'overall_accuracy_vs_sq{file_suffix}_NB.svg'))
        plt.savefig(os.path.join(current_method_figures_dir, f'overall_accuracy_vs_sq{file_suffix}_NB.png'))
        plt.close()

        plt.figure(figsize=(max(12, N_LABELS_EXPECTED * 0.6), max(8, N_LABELS_EXPECTED * 0.4)))
        for lbl_idx_plt in range(N_LABELS_EXPECTED):
            lbl_name_plt = label_encoder.classes_[lbl_idx_plt]
            accs_for_this_lbl_plt = []
            for sq_val_iter_plt in valid_sq_for_plot:
                res_sq = results_for_method[sq_val_iter_plt]
                true_for_lbl_plt = res_sq['true_labels'][res_sq['true_labels'] == lbl_idx_plt]
                pred_for_lbl_plt = res_sq['predictions'][res_sq['true_labels'] == lbl_idx_plt]
                accs_for_this_lbl_plt.append(accuracy_score(true_for_lbl_plt, pred_for_lbl_plt) if len(true_for_lbl_plt) > 0 else np.nan)
            plt.plot(valid_sq_for_plot, accs_for_this_lbl_plt, marker='o', linestyle='-', label=lbl_name_plt)
        
        plt.xlabel('Examples'); plt.ylabel('Accuracy')
        plt.title(f'Accuracy per Label vs. Examples ({method_name}) (NB)')
        plt.xticks(valid_sq_for_plot)
        plt.legend(title="Label", bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.grid(True); plt.tight_layout(rect=[0, 0, 0.85, 1])
        plt.savefig(os.path.join(current_method_figures_dir, f'accuracy_per_label_vs_examples{file_suffix}_NB.svg'))
        plt.savefig(os.path.join(current_method_figures_dir, f'accuracy_per_label_vs_examples{file_suffix}_NB.png'))
        plt.close()

if len(all_methods_testing_results) == 2:
    plt.figure(figsize=(12, 7))
    for method_name, results_for_method in all_methods_testing_results.items():
        overall_accuracies_comp = []
        valid_sq_for_comp = []
        for sq_val in sq_values_plotted:
            if sq_val in results_for_method:
                acc = accuracy_score(results_for_method[sq_val]['true_labels'], results_for_method[sq_val]['predictions'])
                overall_accuracies_comp.append(acc)
                valid_sq_for_comp.append(sq_val)
        if overall_accuracies_comp:
            plt.plot(valid_sq_for_comp, overall_accuracies_comp, marker='o', linestyle='-', label=f'{method_name} Accuracy')

    plt.xlabel('SpeciesQuantity')
    plt.ylabel('Overall Accuracy')
    plt.title('Comparison of Probability Combination Methods')
    plt.xticks(sq_values_plotted)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR_BASE, 'overall_accuracy_comparison_methods_NB.svg'))
    plt.savefig(os.path.join(FIGURES_DIR_BASE, 'overall_accuracy_comparison_methods_NB.png'))
    plt.close()

print("\nAll done.")