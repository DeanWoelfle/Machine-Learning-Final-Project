import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns

def preprocess_data(csv_file_path, min_samples_per_label=4000, output_csv_name="preprocessed_peng_data.csv"):

    try:
        df = pd.read_csv(csv_file_path, on_bad_lines='skip', sep='\t')
    except FileNotFoundError:
        return
    except Exception as e:
        return

    required_columns = ['verbatimScientificName', 'decimalLatitude', 'decimalLongitude']
    if not all(col in df.columns for col in required_columns):
        return

    df = df[df['decimalLatitude'] <= 30] #exclude european zoos

    grouped_data = df.groupby('verbatimScientificName')

    label_counts = {label: len(group) for label, group in grouped_data}
    for label, count in sorted(label_counts.items(), key=lambda item: item[1], reverse=True):
        print(f"{label}: {count}")

    filtered_data = {label: group for label, group in grouped_data if len(group) >= min_samples_per_label and label not in ('SPHENISCIDAE', 'Eudyptula minor novaehollandiae')}

    label_counts = {label: len(group) for label, group in filtered_data.items()}
    for label, count in sorted(label_counts.items(), key=lambda item: item[1], reverse=True):
        print(f"{label}: {count}")

    target_samples = 80000

    augmented_data = []
    for label, group in filtered_data.items():
        if len(group) > target_samples:
            discard_indices = np.random.choice(group.index, size=len(group) - target_samples, replace=False)
            truncated_group = group.drop(discard_indices)
            augmented_data.append(truncated_group)
        elif len(group) < target_samples:
            num_samples_to_add = target_samples - len(group)
            if num_samples_to_add > 0:
                sampled_indices = np.random.choice(group.index, size=num_samples_to_add, replace=True)
                sampled_rows = group.loc[sampled_indices].copy()
                sampled_rows['decimalLatitude'] += np.random.uniform(low=-0.05, high=0.05, size=num_samples_to_add)
                sampled_rows['decimalLongitude'] += np.random.uniform(low=-0.05, high=0.05, size=num_samples_to_add)
                augmented_group = pd.concat([group, sampled_rows], ignore_index=True)
                augmented_data.append(augmented_group)
        else:
            augmented_data.append(group)

    final_df = pd.concat(augmented_data, ignore_index=True)

    final_grouped = final_df.groupby('verbatimScientificName')
    label_counts = {label: len(group) for label, group in final_grouped}
    for label, count in sorted(label_counts.items(), key=lambda item: item[1], reverse=True):
        print(f"{label}: {count}")

    print(f"\nPreprocessed data saved to {output_csv_name}")

    return final_df

if __name__ == "__main__":

    csv_file_path = "extracted_columns_peng.csv"
    
    if not os.path.exists(csv_file_path):
        pass
    else:
        final_df = preprocess_data(csv_file_path, min_samples_per_label=4000, output_csv_name="preprocessed_peng_data.csv")

        if final_df is not None:
            if final_df is not None:
                plt.figure(figsize=(12, 8))
                unique_labels = final_df['verbatimScientificName'].unique()
                n_labels = len(unique_labels)
                label_to_color = plt.cm.get_cmap('tab20', n_labels)
                color_map = {label: label_to_color(i) for i, label in enumerate(unique_labels)}

                fraction_to_plot = 1.0

                for label in unique_labels:
                    subset_df = final_df[final_df['verbatimScientificName'] == label]
                    n_to_plot = int(len(subset_df) * fraction_to_plot)
                    if n_to_plot > 0:
                        sampled_df = subset_df.sample(n=n_to_plot, random_state=360)
                        plt.scatter(sampled_df['decimalLongitude'], sampled_df['decimalLatitude'],
                                    label=label, color=color_map[label], s=10, alpha=0.6)

                plt.xlabel('Longitude')
                plt.ylabel('Latitude')
                plt.title('Data Points by Label (25% Sampled)')
                plt.legend(title='Species', bbox_to_anchor=(1.05, 1), loc='upper left')
                plt.grid(True)
                plt.tight_layout()
                plt.savefig("datapoints_by_label.png")
                plt.savefig("datapoints_by_label.svg")
                plt.show()