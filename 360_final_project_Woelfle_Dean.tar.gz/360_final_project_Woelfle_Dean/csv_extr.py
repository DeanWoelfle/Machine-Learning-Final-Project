import pandas as pd
import os
import pytaxize
from pytaxize import scicomm

def extract_and_save_columns(input_csv_path, output_filename, columns_to_extract, batch_size=10000):
    output_csv_path = os.path.join(os.path.dirname(input_csv_path), output_filename)

    try:
        first_chunk = True
        for chunk in pd.read_csv(input_csv_path, chunksize=batch_size, sep='\t'):
            try:
                selected_columns_chunk = chunk[columns_to_extract]
            except KeyError as e:
                return

            selected_columns_chunk.to_csv(output_csv_path, mode='a', header=first_chunk, index=False, sep='\t')

            if first_chunk:
                first_chunk = False

        print(f"Extracted columns {columns_to_extract} and saved to {output_csv_path}")

    except FileNotFoundError:
        pass
    except Exception as e:
        pass

def print_first_row_with_columns_explicit(input_csv_path, max_rows=1):
    try:
        csv_iterator = pd.read_csv(input_csv_path, iterator=True, sep='\t')
        chunk = csv_iterator.get_chunk(max_rows)
        column_names = chunk.columns.tolist()
        for col in column_names:
            print(f"- '{col}'")
    except FileNotFoundError:
        pass
    except Exception as e:
        pass

import pandas as pd

def get_values_for_columns_in_row(input_csv_path, row_number, columns_to_get):
    try:
        header_df = pd.read_csv(input_csv_path, nrows=0, sep='\t')
        correct_column_names = header_df.columns.tolist()

        data_df = pd.read_csv(input_csv_path, skiprows=row_number, nrows=1, sep='\t', header=None)

        if data_df.empty:
            return None

        row_data = data_df.iloc[0].tolist()
        row_dict = dict(zip(correct_column_names, row_data))

        result = {}
        for col in columns_to_get:
            if col in row_dict:
                result[col] = row_dict[col]
            else:
                return None

        return result

    except FileNotFoundError:
        return None
    except Exception as e:
        return None


if __name__ == "__main__":
    input_file = 'peng_large.csv'
    
    print_first_row_with_columns_explicit(input_file)
    
    row_to_inspect = 2
    columns_of_interest = ['verbatimScientificName', 'decimalLatitude', 'decimalLongitude'] 
    #columns_of_interest = ['gbifID', 'datasetKey', 'occurrenceID', 'kingdom', 'phylum', 'class', 'order', 'family', 'genus', 'species', 'infraspecificEpithet', 'taxonRank', 'scientificName', 'verbatimScientificName', 'verbatimScientificNameAuthorship', 'countryCode', 'locality', 'stateProvince', 'occurrenceStatus', 'individualCount', 'publishingOrgKey', 'decimalLatitude', 'decimalLongitude', 'coordinateUncertaintyInMeters', 'coordinatePrecision', 'elevation', 'elevationAccuracy', 'depth', 'depthAccuracy', 'eventDate', 'day', 'month', 'year', 'taxonKey', 'speciesKey', 'basisOfRecord', 'institutionCode', 'collectionCode', 'catalogNumber', 'recordNumber', 'identifiedBy', 'dateIdentified', 'license', 'rightsHolder', 'recordedBy', 'typeStatus', 'establishmentMeans', 'lastInterpreted', 'mediaType', 'issue']#, 'year']

    row_values = get_values_for_columns_in_row(input_file, row_to_inspect, columns_of_interest)

    if row_values:
        print(f"Values for Row {row_to_inspect + 1} and Columns {columns_of_interest}:")
        for col, value in row_values.items():
            print(f"{col}: {value}")

    output_file = 'extracted_columns_peng.csv'
    columns_to_keep = ['verbatimScientificName', 'decimalLatitude', 'decimalLongitude']

    extract_and_save_columns(input_file, output_file, columns_to_keep)
    